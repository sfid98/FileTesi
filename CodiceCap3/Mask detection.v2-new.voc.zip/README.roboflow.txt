
Mask detection - v2 new
==============================

This dataset was exported via roboflow.ai on September 19, 2021 at 4:01 PM GMT

It includes 833 images.
Try are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


